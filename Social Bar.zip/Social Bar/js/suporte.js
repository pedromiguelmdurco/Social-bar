function suporte010() {
    var a = document.getElementById("suporte01");
    var b = document.getElementById("suporte02");
    var c = document.getElementById("suporte03");
    var d = document.getElementById("suporte04");
    var e = document.getElementById("suporte05");
    var f = document.getElementById("suporte06");
    var g = document.getElementById("suporte07");

    if (a.style.display === "block") {
      a.style.display = "none";
    }
    else {
      a.style.display = "block";
      b.style.display = "none";
      c.style.display = "none";
      d.style.display = "none";
      e.style.display = "none";
      f.style.display = "none";
      g.style.display = "none";
    }
  }

  function suporte011() {
    var a = document.getElementById("suporte01");
    var b = document.getElementById("suporte02");
    var c = document.getElementById("suporte03");
    var d = document.getElementById("suporte04");
    var e = document.getElementById("suporte05");
    var f = document.getElementById("suporte06");
    var g = document.getElementById("suporte07");

    if (b.style.display === "block") {
      b.style.display = "none";
    }
    else {
      a.style.display = "none";
      b.style.display = "block";
      c.style.display = "none";
      d.style.display = "none";
      e.style.display = "none";
      f.style.display = "none";
      g.style.display = "none";
    }
  }

  function suporte012() {
    var a = document.getElementById("suporte01");
    var b = document.getElementById("suporte02");
    var c = document.getElementById("suporte03");
    var d = document.getElementById("suporte04");
    var e = document.getElementById("suporte05");
    var f = document.getElementById("suporte06");
    var g = document.getElementById("suporte07");

    if (c.style.display === "block") {
      c.style.display = "none";
    }
    else {
      a.style.display = "none";
      b.style.display = "none";
      c.style.display = "block";
      d.style.display = "none";
      e.style.display = "none";
      f.style.display = "none";
      g.style.display = "none";
    }
  }

  function suporte013() {
    var a = document.getElementById("suporte01");
    var b = document.getElementById("suporte02");
    var c = document.getElementById("suporte03");
    var d = document.getElementById("suporte04");
    var e = document.getElementById("suporte05");
    var f = document.getElementById("suporte06");
    var g = document.getElementById("suporte07");

    if (d.style.display === "block") {
      d.style.display = "none";
    }
    else {
      a.style.display = "none";
      b.style.display = "none";
      c.style.display = "none";
      d.style.display = "block";
      e.style.display = "none";
      f.style.display = "none";
      g.style.display = "none";
    }
  }

  function suporte014() {
    var a = document.getElementById("suporte01");
    var b = document.getElementById("suporte02");
    var c = document.getElementById("suporte03");
    var d = document.getElementById("suporte04");
    var e = document.getElementById("suporte05");
    var f = document.getElementById("suporte06");
    var g = document.getElementById("suporte07");

    if (e.style.display === "block") {
      e.style.display = "none";
    }
    else {
      a.style.display = "none";
      b.style.display = "none";
      c.style.display = "none";
      d.style.display = "none";
      e.style.display = "block";
      f.style.display = "none";
      g.style.display = "none";
    }
  }

  function suporte015() {
    var a = document.getElementById("suporte01");
    var b = document.getElementById("suporte02");
    var c = document.getElementById("suporte03");
    var d = document.getElementById("suporte04");
    var e = document.getElementById("suporte05");
    var f = document.getElementById("suporte06");
    var g = document.getElementById("suporte07");

    if (f.style.display === "block") {
      f.style.display = "none";
    }
    else {
      a.style.display = "none";
      b.style.display = "none";
      c.style.display = "none";
      d.style.display = "none";
      e.style.display = "none";
      f.style.display = "block";
      g.style.display = "none";
    }
  }

  function suporte016() {
    var a = document.getElementById("suporte01");
    var b = document.getElementById("suporte02");
    var c = document.getElementById("suporte03");
    var d = document.getElementById("suporte04");
    var e = document.getElementById("suporte05");
    var f = document.getElementById("suporte06");
    var g = document.getElementById("suporte07");

    if (g.style.display === "block") {
      g.style.display = "none";
    }
    else {
      a.style.display = "none";
      b.style.display = "none";
      c.style.display = "none";
      d.style.display = "none";
      e.style.display = "none";
      f.style.display = "none";
      g.style.display = "block";
    }
  }

